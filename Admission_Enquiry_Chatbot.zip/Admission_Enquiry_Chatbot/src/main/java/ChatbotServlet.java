
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ChatbotServlet")
public class ChatbotServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        String userQuery = request.getParameter("query");
        String botResponse = getBotResponse(userQuery);

        out.print(botResponse);
    }

    private String getBotResponse(String query) {
        String response = "Sorry, I couldn't understand your question.";
        
        // Database credentials (consider moving them to a config file)
        String url = "jdbc:mysql://localhost:3306/admission_enquiry";
        String user = "root";
        String password = "Raman@143";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(url, user, password);
                 PreparedStatement stmt = conn.prepareStatement("SELECT answer FROM chatbot_data WHERE question LIKE ?")) {

                stmt.setString(1, "%" + query + "%");

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        response = rs.getString("answer");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log the error for debugging
            response = "An error occurred while fetching the response.";
        }

        return response;
    }
}



