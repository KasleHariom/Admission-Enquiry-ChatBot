function sendMessage() {
    let userMessage = document.getElementById("user-input").value.trim();
    if (userMessage) {
        let chatboxBody = document.getElementById("chatbox-body");

        // Append user message
        let userMessageDiv = document.createElement("div");
        userMessageDiv.classList.add("message", "user-message");
        userMessageDiv.textContent = userMessage;
        chatboxBody.appendChild(userMessageDiv);

        document.getElementById("user-input").value = '';

        fetch('chatbotServlet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'query=' + encodeURIComponent(userMessage), // Ensure it matches the servlet
        })
        .then(response => response.text())
        .then(data => {
            let botMessageDiv = document.createElement("div");
            botMessageDiv.classList.add("message", "bot-message");
            botMessageDiv.textContent = data;
            chatboxBody.appendChild(botMessageDiv);

            // Auto-scroll to the latest message
            chatboxBody.scrollTop = chatboxBody.scrollHeight;
        })
        .catch(error => {
            console.error('Error:', error);

            // Show error message in chatbox
            let errorDiv = document.createElement("div");
            errorDiv.classList.add("message", "bot-message", "error-message");
            errorDiv.textContent = "Sorry, an error occurred. Please try again.";
            chatboxBody.appendChild(errorDiv);
        });
    }
}

